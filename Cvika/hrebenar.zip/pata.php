<footer>
<p>vytvoril: <em><?php echo AUTOR . ', ' . WEB; ?></em></p>
</footer>

</body>
</html>
