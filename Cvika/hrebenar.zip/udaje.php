<?php
define("AUTOR", "UWT team");
define("WEB", "FMFI UK");
$sh_hodina = 10;
$sh_minuty = 30;
$sh_text = "Práve prebieha šťastná polhodinka - zľava 10%";

?>