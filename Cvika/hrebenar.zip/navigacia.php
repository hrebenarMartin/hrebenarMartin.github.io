<nav>
<a href="index.php">index</a> <a href="ponuka.php">ponuka</a> <a href="objednavka.php">objednávka</a> <a href="kontakt.php">kontakt</a> <a href="administracia.php">administrácia</a>
</nav>
