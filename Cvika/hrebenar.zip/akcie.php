<aside>
<h1>Akcie na tento týždeň</h1>
<p><em>Potešenie z orchideí</em><br>
Pripravili sme pre Vás túto radostnú kyticu zloženú zo šiestich veľkokvetých orchideí a bohatej zelene. cena: <strong>26,52 &euro;</strong></p>
<p><em>Maslové ruže</em><br>
21 maslových ruží, ideálny darček ku každej príležitosti. cena: <strong>59,72 &euro;</strong></p>
</aside>
