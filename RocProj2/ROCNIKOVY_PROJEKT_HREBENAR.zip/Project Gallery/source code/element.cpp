/*
 * element.cpp
 *
 * @author Martin Hrebe��r
 */

#include "helpers.h"

using namespace std;

element::element(std::ifstream& file_stream)
{

	pic_ = nullptr;
	prev_ = nullptr;
	next_ = nullptr;

	// TODO read from file implementation

	auto chars = 0;
	auto index = 0;

	char * input;

	queue<char> data_q;
	while (true)
	{
		string line;
		getline(file_stream, line);
		if (line.empty())
		{
			input = static_cast<char*>(malloc(chars * sizeof(char) + 1));
			while (!data_q.empty())
			{
				input[index++] = data_q.front();
				data_q.pop();
			}
			input[index] = '\0';
			break;
		}

		istringstream iss(line);
		iss >> noskipws;
		char ch;
		while (iss >> ch) {
			data_q.push(ch);
			chars++;
		}
		data_q.push('\n');
		chars++;
	}

	picture * new_pic = nullptr;

	try
	{
		new_pic = new picture(input);
		set_picture(new_pic);
	}
	catch (int e)
	{
		if (new_pic != nullptr) delete new_pic;

		throw;
	}
}

element::element(std::istream& in_stream = cin)
{

	pic_ = nullptr;
	prev_ = nullptr;
	next_ = nullptr;

	auto chars = 0;
	auto index = 0;

	auto line_number = 1;

	char * input;

	cout << "\t\t      ----  EDIT MODE  ----\n\n";
	cout << "       |v--------v---------v---------v---------v---------v|\n";

	queue<char> data_q;
	while (true)
	{
		cout << " " << line_number << ":\t";
		string line;
		getline(in_stream, line);
		if (line.empty()) 
		{
			input = static_cast<char*>(malloc(chars * sizeof(char) + 1));
			while (!data_q.empty())
			{
				input[index++] = data_q.front();
				data_q.pop();
			}
			input[index] = '\0';
			break;
		}

		istringstream iss(line);
		iss >> noskipws;
		char ch;
		while (iss >> ch) {
			data_q.push(ch);
			chars++;
		}
		data_q.push('\n');
		chars++;
		line_number++;
	}

	cout << "       |--------------------------------------------------|\n";

	picture * new_pic = nullptr;

	try
	{
		new_pic = new picture(input);
		set_picture(new_pic);
	}
	catch(int e)
	{
		if (new_pic != nullptr) delete new_pic;

		throw;
	}
}

element::~element()
{

#ifdef DEBUG
	cout << "[DEBUG] Deleting element" << endl;
#endif

	if (pic_ != nullptr) delete pic_;
}
