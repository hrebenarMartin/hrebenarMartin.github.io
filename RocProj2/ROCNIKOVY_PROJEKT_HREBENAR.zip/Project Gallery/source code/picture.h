/*
 * picture.h
 * 
 * @author Martin Hrebe��r
 */

#ifndef PICTURE_H
#define PICTURE_H

class picture
{
	char * raw_input_;
	int raw_input_length_;

	char ** lines_;
	int number_of_lines_; //height
	int max_line_length_; //width

public:
	explicit picture(char * input);
	~picture();
	char * ret_line(int index) const;

	int get_height() const { return number_of_lines_; }
	int get_width() const { return max_line_length_; }

private:
	int count_lines() const;
	int max_line_length() const;
	void parse_input();
};

#endif
