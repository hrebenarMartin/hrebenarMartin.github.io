﻿/*
 * gallery_io.cpp
 *
 * @author Martin Hrebeňár
 */

#include "helpers.h"

using namespace std;


void print_top_line() {
	cout << "======================================================= GALLERY ========================================================\n\n";
}

void print_bottom_line() {
	cout << "\n========================================================================================================================\n";
}

void print_middle_line()
{
	cout << "\n\t\t\t    ----------------------------------------------------------------\n";
}

void help() {
	cout << "\n----\t COMMAND LINE ARGUMENTS\nApplication accepts none or only one argument listed below\n";
	cout << "\n-t\t Runs unit tests before starting application\n";
	cout << "\n----\t BASIC COMMANDS\n";
	cout << "n\t loads new image in edit mode\n";
	cout << "d\t delete actual (first from left) image\n";
	cout << "l r\t gallery rotation to right (r) or to left (l)\n";
	cout << "s\t prints number of images in gallery\n";
	cout << "+\t increase number of shown pictures\n";
	cout << "-\t decrease number of shown pictures\n";
	cout << "h\t shows this help\n";
	cout << "q\t shut down program\n";
}

void succesful_picture_creation()
{
	const auto h_console = GetStdHandle(STD_OUTPUT_HANDLE);
	SetConsoleTextAttribute(h_console, 4);
	cout << ANSI_COLOR_GREEN << "\nPicture is correct and was added to gallery." << ANSI_COLOR_RESET << endl;
	SetConsoleTextAttribute(h_console, 15);
}

void handle_error(const int err_code)
{

	if (err_code == OK) return;

	print_middle_line();

	cout << ANSI_COLOR_RED << internal << "\n\t";

	cout << "ERROR " << err_code;

	switch (err_code)
	{
	case ERR_GALLERY_SHOW_COUNT_TOO_HIGH:			cout << " --- Cannot raise number of shown images. Maximum value ( " << GALLERY_SHOW_MAX << " ) reached.\n"; break;
	case ERR_GALLERY_SHOW_COUNT_TOO_LOW:			cout << " --- Cannot lower number of shown images. Minimum value (1) reached.\n"; break;
	case ERR_UNKNOWN_COMMAND:						cout << " --- Unknown command entered. Try again please or use ' h ' command to show commands list.\n"; break;
	case ERR_PICTURE_LINES_LIMIT_EXCEEDED:			cout << " --- Picture height is over limit ( " << PICTURE_MAX_LINES << " )\n"; break;
	case ERR_PICTURE_LINE_WIDTH_LIMIT_EXCEEDED:		cout << " --- Picture maximal width is over limit ( " << PICTURE_MAX_LINE_LENGTH << " )\n"; break;
	case ERR_EMPTY_PICTURE:							cout << " --- Empty picture entered.\n"; break;
	default:								break;
	}
	if (err_code == ERR_PICTURE_LINES_LIMIT_EXCEEDED || err_code == ERR_PICTURE_LINE_WIDTH_LIMIT_EXCEEDED || err_code == ERR_EMPTY_PICTURE) 
		cout << "\tAny changes won't be saved!\n";

	cout << ANSI_COLOR_RESET;
}