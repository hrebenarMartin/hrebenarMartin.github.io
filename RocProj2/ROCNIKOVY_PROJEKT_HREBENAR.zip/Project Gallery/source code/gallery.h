/*
 *gallery.h
 *
 *@author Martin Hrebe��r
 */

#ifndef GALLERY_H
#define GALLERY_H

#include "element.h"

class gallery
{
	unsigned int gallery_size_;
	element * current_element_;
	element * first_element_;
	element * last_element_;
	unsigned short show_count_ = 1;

public:
	gallery();
	~gallery();
	void add_element(element * element);
	void delete_element();
	void show_gallery() const;
	void rotate_left();
	void rotate_right();
	int show_more();
	int show_less();
	
	int get_gallery_size() const { return gallery_size_; }
	element * get_current() const { return current_element_; }

private:
	static char * generate_empty_line(unsigned int length);
	
};

#endif