#define _CRT_SECURE_NO_WARNINGS

#include "gtest/gtest.h"

using namespace std;

#include "helpers.h"

using namespace ::testing;


TEST_F(Test, TestCreatingEmptyPicture)
{
	auto * ifs = new ifstream("testEmpty.txt");
	element * el = nullptr;

	if (ifs != nullptr) {
		ASSERT_ANY_THROW(el = new element(*ifs));
		ifs->close();
	}
	if (el != nullptr) delete el;
	
}

TEST_F(Test, TestCreatingTooWidePicture)
{
	auto * ifs = new ifstream("testTooWidePicture.txt");
	element * el = nullptr;


	if (ifs != nullptr) {
		ASSERT_ANY_THROW(el = new element(*ifs));
		ifs->close();
	}

	if (el != nullptr) delete el;

}

TEST_F(Test, TestCreatingTooLongPicture)
{
	auto * ifs = new ifstream("testTooLongPicture.txt");
	element * el = nullptr;

	if (ifs != nullptr) {
		ASSERT_ANY_THROW(el = new element(*ifs));
		ifs->close();
	}

	if (el != nullptr) delete el;
}

TEST_F(Test, TestCreatingCorrectPicture)
{
	auto * ifs = new ifstream("testCorrectPicture.txt");
	element * el = nullptr;

	if (ifs != nullptr) {
		ASSERT_NO_THROW(el = new element(*ifs));
		ifs->close();
	}

	if (el != nullptr) delete el;

}

TEST_F(Test, TestStartApllication)
{
	auto * test = new application();

	ASSERT_EQ(0, test->get_gallery()->get_gallery_size());

	delete test;
}

TEST_F(Test, TestAddingCorrectPictureToGallery)
{
	auto * test = new application();
	auto * ifs = new ifstream("testCorrectPicture.txt");
	element * el = nullptr;

	if (ifs != nullptr)
	{
		ASSERT_NO_THROW(el = new element(*ifs));
		ifs->close();
	}

	if (el != nullptr) test->get_gallery()->add_element(el);

	ASSERT_EQ(1, test->get_gallery()->get_gallery_size());

	delete test;
}

TEST_F(Test, TestAddingIncorrectPictureToGallery)
{
	auto * test = new application();
	auto * ifs = new ifstream("testTooLongPicture.txt");
	element * el = nullptr;

	if (ifs != nullptr)
	{
		ASSERT_ANY_THROW(el = new element(*ifs));
		ifs->close();
	}

	if (el != nullptr)test->get_gallery()->add_element(el);

	ASSERT_EQ(0, test->get_gallery()->get_gallery_size());

	delete test;
}

TEST_F(Test, TestAddingMultipleCorrectPicturesToGallery)
{
	auto * test = new application();
	element * el = nullptr;

	for (auto i = 0; i < 10; i++)
	{
		auto * ifs = new ifstream("testCorrectPicture.txt");

		if (ifs != nullptr) {
			ASSERT_NO_THROW(el = new element(*ifs));
			ifs->close();
		}

		if (el != nullptr)test->get_gallery()->add_element(el);
	}

	ASSERT_EQ(10, test->get_gallery()->get_gallery_size());

	delete test;
}

TEST_F(Test, TestAddingTooManyCorrectPicturesToGallery)
{
	auto * test = new application();
	element * el = nullptr;

	for (auto i = 0; i < 51; i++)
	{
		auto * ifs = new ifstream("testCorrectPicture.txt");

		if (ifs != nullptr) {
			ASSERT_NO_THROW(el = new element(*ifs));
			ifs->close();
		}

		try {
			if (el != nullptr) test->get_gallery()->add_element(el);
		}
		catch (int e) {}
	}

	ASSERT_EQ(50, test->get_gallery()->get_gallery_size());

	delete test;
}

TEST_F(Test, TestDeletingPictureFromGallery)
{
	auto * test = new application();
	element * el = nullptr;

	for (auto i = 0; i < 10; i++)
	{
		auto * ifs = new ifstream("testCorrectPicture.txt");

		if (ifs != nullptr) {
			ASSERT_NO_THROW(el = new element(*ifs));
			ifs->close();
		}

		if (el != nullptr)test->get_gallery()->add_element(el);
	}

	ASSERT_EQ(10, test->get_gallery()->get_gallery_size());

	test->get_gallery()->delete_element();

	ASSERT_EQ(9, test->get_gallery()->get_gallery_size());

	delete test;
}

TEST_F(Test, TestLoveringGalleryShowCountUnderLimit)
{
	auto * test = new application();

	ASSERT_EQ(0, test->get_gallery()->get_gallery_size());

	ASSERT_EQ(ERR_GALLERY_SHOW_COUNT_TOO_LOW, test->get_gallery()->show_less());

	delete test;
}

TEST_F(Test, TestRaisingGalleryShowCountOverLimit)
{
	auto * test = new application();

	ASSERT_EQ(0, test->get_gallery()->get_gallery_size());

	for (auto i = 0; i < GALLERY_SHOW_MAX - 1; test->get_gallery()->show_more(), i++);

	ASSERT_EQ(ERR_GALLERY_SHOW_COUNT_TOO_HIGH, test->get_gallery()->show_more());

	delete test;
}

TEST_F(Test, TestRaisingGalleryShowCountCorrectly)
{
	auto * test = new application();

	ASSERT_EQ(0, test->get_gallery()->get_gallery_size());

	for (auto i = 0; i < GALLERY_SHOW_MAX - 4; test->get_gallery()->show_more(), i++);

	ASSERT_EQ(OK
		, test->get_gallery()->show_more());

	delete test;
}

TEST_F(Test, TestLoweringGalleryShowCountCorrectly)
{
	auto * test = new application();

	ASSERT_EQ(0, test->get_gallery()->get_gallery_size());

	test->get_gallery()->show_more();

	ASSERT_EQ(OK, test->get_gallery()->show_less());

	delete test;
}
