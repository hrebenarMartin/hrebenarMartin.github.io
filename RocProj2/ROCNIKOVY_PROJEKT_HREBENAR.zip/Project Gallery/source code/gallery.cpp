/*
 * gallery.cpp
 *
 * @author Martin Hrebe��r
 */

#include "helpers.h"

using namespace std;

gallery::gallery()
{
	gallery_size_ = 0;
	current_element_ = nullptr;
	first_element_ = nullptr;
	last_element_ = nullptr;
	show_count_ = 1;
}

void gallery::add_element(element * element)
{

	if (gallery_size_ == GALLERY_PICTURE_LIMIT) throw ERR_GALLERY_PICTURE_LIMIT_EXCEEDED;

	if (gallery_size_ == 0) {
		current_element_ = element;
		current_element_->set_next(element);
		current_element_->set_prev(element);
		first_element_ = element;
		last_element_ = element;
	}
	else {
		element->set_next(first_element_);
		element->set_prev(last_element_);
		last_element_->set_next(element);
		last_element_ = element;
		first_element_->set_prev(last_element_);
		current_element_ = last_element_;
	}
	gallery_size_++;
}

void gallery::delete_element()
{
	if (get_gallery_size() > 0 && current_element_ != nullptr) {

		element *tmp = current_element_;

		current_element_ = current_element_->get_next();
		tmp->get_next()->set_prev(tmp->get_prev());
		tmp->get_prev()->set_next(tmp->get_next());

		delete tmp;

		gallery_size_--;
	}
}

char * gallery::generate_empty_line(unsigned int length)
{
	auto *res = static_cast<char*>(malloc((length + 1) * sizeof(char)));
	memset(res, ' ', length);
	res[length] = '\0';
	return res;
}

void gallery::show_gallery() const
{
	if (gallery_size_ > 0) {

		const unsigned short real_show_count = gallery_size_ >= show_count_ ? show_count_ : gallery_size_;
		unsigned int max_height = 0;


		auto * tmp = current_element_;
		for (auto i = 0; i < real_show_count; i++)
		{
			max_height = tmp->get_picture()->get_height() > max_height ? tmp->get_picture()->get_height() : max_height;
			tmp = tmp->get_next();
		}

		int * height_diff = nullptr; //NYI
		if (real_show_count > 1)
		{
			tmp = current_element_;
			height_diff = new int[real_show_count];
			for (auto i = 0; i < real_show_count; i++)
			{
				height_diff[i] = max_height - tmp->get_picture()->get_height();
				tmp = tmp->get_next();
			}
		}


#ifdef DEBUG
		cout << "[DEBUG] Will be showing " << real_show_count << " pictures." << endl;
		cout << "[DEBUG] Max image height is " << max_height << "." << endl;

		cout << "[DEBUG] TEST generate empty line of length 20 ||>" << generate_empty_line(20) << "<||\n" << endl;

		cout << "[DEBUG] height diff array: [NYI]" << height_diff << endl;
		if (height_diff != nullptr)	//NYI
		{
			for (auto i = 0; i < real_show_count; i++)
			{
				cout << "\t\t Diff " << i + 1 << ": " << height_diff[i] << endl;
			}
		}
		print_middle_line();

		cout << "\n";

#endif

		if (real_show_count == 1)
		{
			for (auto i = 0; i < current_element_->get_picture()->get_height(); ++i) {
				cout << "\t" << current_element_->get_picture()->ret_line(i) << endl;
			}
			return;
		}
		
		tmp = current_element_;
		for (auto i = 0; i < max_height; i++)
		{
			cout << "\t";
			for (auto j = 0; j < real_show_count; j++)
			{
				if (j > 0) cout << "  ||  ";

				if (i < tmp->get_picture()->get_height())
				{
					cout << setw(tmp->get_picture()->get_width()) << left << tmp->get_picture()->ret_line(i);
				}
				else cout << generate_empty_line(tmp->get_picture()->get_width());

				tmp = tmp->get_next();

			}
			cout << endl;
			tmp = current_element_;
		}

		if (height_diff != nullptr) delete[] height_diff;

	}
	else {
		printf("\t\t\t\t     Gallery is yet to be filled with amazing arts. :)\n");
	}
}

void gallery::rotate_left()
{
	if (gallery_size_ > 1) {
		for (auto i = 0; i < show_count_; i++)	current_element_ = current_element_->get_next();
	}
}

void gallery::rotate_right()
{
	if (gallery_size_ > 1) {
		for (auto i = 0; i < show_count_; i++)	current_element_ = current_element_->get_prev();
	}
}

int gallery::show_more()
{
	if (show_count_ < GALLERY_SHOW_MAX) {
		show_count_++;
		return OK;
	}
	return ERR_GALLERY_SHOW_COUNT_TOO_HIGH;
}

int gallery::show_less()
{
	if (show_count_ > 1)
	{
		show_count_--;
		return OK;
	}
	return ERR_GALLERY_SHOW_COUNT_TOO_LOW;
}

gallery::~gallery()
{
	const int tmp = gallery_size_;
	for (int i = 0; i < tmp; i++)
	{
		delete_element();
	}
	first_element_ = nullptr;
	last_element_ = nullptr;

#ifdef DEBUG
	cout << "[DEBUG] Deleting gallery" << endl;
#endif
}

