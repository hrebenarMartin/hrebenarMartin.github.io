/*
 * helpers.h
 * 
 * @author Martin Hrebe��r
 */

#ifndef HELPERS_H
#define HELPERS_H

#include <cstdlib>
#include <cstdio>
#include <cstring>
#include <cmath>
#include <Windows.h>
#include <iostream>
#include <fstream>
#include <istream>
#include <sstream>
#include <string>
#include <queue>
#include <iomanip>

#include "picture.h"
#include "element.h"
#include "gallery.h"
#include "gallery_io.h"
#include "gallery_main.h"

//debug prints, comment if want to disable
//#define DEBUG

//prints colors
#define ANSI_COLOR_RED     "\x1b[91m"
#define ANSI_COLOR_GREEN   "\x1b[92m"
#define ANSI_COLOR_RESET   "\x1b[0m"

//gallery config macros
#define GALLERY_SHOW_MAX 5
#define GALLERY_PICTURE_LIMIT 50
#define PICTURE_MAX_LINES 50
#define PICTURE_MAX_LINE_LENGTH 50

//succes macro
#define OK 1

// gallery related errors
#define ERR_GALLERY_SHOW_COUNT_TOO_HIGH 401
#define ERR_GALLERY_SHOW_COUNT_TOO_LOW 402
#define ERR_GALLERY_PICTURE_LIMIT_EXCEEDED 403
//element related errors
//-- TODO
//picture related errors
#define ERR_PICTURE_MEMORY_ALLOCATION_ERROR 501
#define ERR_PICTURE_LINES_LIMIT_EXCEEDED 502
#define ERR_PICTURE_LINE_WIDTH_LIMIT_EXCEEDED 503
#define ERR_EMPTY_PICTURE 504
//general errors
#define ERR_UNKNOWN_COMMAND 600
#define FATAL_ERR_CODE 999

#endif
