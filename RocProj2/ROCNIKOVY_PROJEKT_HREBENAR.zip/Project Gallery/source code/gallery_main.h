/*
* gallery_main.h
*
* @author Martin Hrebe��r
*/

#ifndef GALLERY_MAIN_H
#define GALLERY_MAIN_H

#include "gallery.h"

class application
{
	gallery * gallery_;
	bool run_ = true;

public:
	application();
	~application();
	void start();
	void execute_command(char command);

	void stop() { run_ = false; }
	bool is_runnning() const { return run_; }
	gallery * get_gallery() const { return gallery_; }
};

int start_application();

#endif
