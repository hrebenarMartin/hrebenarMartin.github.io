/*
* gallery_main.cpp
*
* @author Martin Hrebe��r
*/

#include "helpers.h"

using namespace std;

application::application()
{
	gallery_ = new gallery();
}

void application::start()
{
	print_top_line();
	gallery_->show_gallery();
	print_middle_line();
	help();
	print_bottom_line();

	while (is_runnning())
	{
		printf(">> ");
		char command = getchar();
		if (command != '\n' && getchar() != '\n') {
			while (command != '\n') {
				command = getchar();
			}
			system("cls");
			execute_command('x');	// deliberately execute not valid command to match output
		}
		else {
			execute_command(command);
		}
	}
}

void application::execute_command(const char command)
{
	if (command != '\n') system("cls");
	else return;

	if (command == 'q')
	{
		stop();
		return;
	}

	element * new_element = nullptr;
	auto tmp = 0;

	switch (command) {
	case 'n':
		try
		{
			print_top_line();

			new_element = new element(cin);
			gallery_->add_element(new_element);

			print_bottom_line();

			succesful_picture_creation();

			char tmp;
			cout << "Press ENTER to continue...";
			cin >> noskipws >> tmp;

			system("cls");

			print_top_line();
			gallery_->show_gallery();
			print_bottom_line();
		}
		catch (int e)
		{
			//print_middle_line();
			handle_error(e);
			print_bottom_line();
			if (new_element != nullptr) delete new_element;
		}
		break;
	case 'd':	print_top_line(); gallery_->delete_element(); gallery_->show_gallery(); print_bottom_line(); break;
	case 'l':	print_top_line(); gallery_->rotate_left(); gallery_->show_gallery(); print_bottom_line(); break;
	case 'r':   print_top_line(); gallery_->rotate_right(); gallery_->show_gallery(); print_bottom_line(); break;
	case 's':	print_top_line(); gallery_->show_gallery(); print_middle_line(); cout << "\nThe gallery have " << gallery_->get_gallery_size() << "/" << GALLERY_PICTURE_LIMIT << " pictures stored." << endl; print_bottom_line(); break;
	case 'h':	print_top_line(); gallery_->show_gallery(); print_middle_line(); help(); print_bottom_line(); break;
	case '+':
		print_top_line();
		tmp = gallery_->show_more();
		gallery_->show_gallery();
		handle_error(tmp);
		print_bottom_line();
		break;
	case '-':
		print_top_line();
		tmp = gallery_->show_less();
		gallery_->show_gallery();
		handle_error(tmp);
		print_bottom_line();
		break;
	default:	print_top_line(); gallery_->show_gallery(); handle_error(ERR_UNKNOWN_COMMAND); print_bottom_line(); break;
	}


}

application::~application()
{
	if (gallery_ != nullptr) delete gallery_;
#ifdef DEBUG
	cout << "[DEBUG] Deleting application mainframe" << endl;
#endif
}

int start_application()
{
	auto * app_gallery = new application();

	app_gallery->start();

	delete app_gallery;

#ifdef DEBUG

	cout << "[DEBUG] Application has stopped running." << endl;

	int a;
	cin >> noskipws;
	cin >> a;
#endif

	return 1;

}