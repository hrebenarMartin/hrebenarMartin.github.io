/*
 * gallery_io.h
 * 
 * @author Martin Hrebe��r
 */

#ifndef GALLERY_IO_H
#define GALLERY_IO_H

void print_top_line();
void print_bottom_line();
void print_middle_line();
void help();
void succesful_picture_creation();

void handle_error(int);

#endif
