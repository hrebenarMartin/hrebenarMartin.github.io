/*
 * element.h
 *
 * @author Martin Hrebe��r
 */

#ifndef ELEMENT_H
#define ELEMENT_H

#include "picture.h"

class element 
{
	picture * pic_;
	element * prev_;
	element * next_;

public:
	explicit element(std::ifstream& file_stream);
	explicit element(std::istream& in_stream);
	~element();

	void set_next(element * next) { this->next_ = next; }
	element * get_next() const { return next_; }

	void set_prev(element * prev) { this->prev_ = prev; }
	element * get_prev() const { return prev_; }

	void set_picture(picture * pic) { this->pic_ = pic; }
	picture * get_picture() const { return pic_; }
};


#endif