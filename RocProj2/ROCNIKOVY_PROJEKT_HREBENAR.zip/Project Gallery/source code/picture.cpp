/*
 * picture.cpp
 *
 * @author Martin Hrebe��r
 */
#define _CRT_SECURE_NO_WARNINGS
#include "helpers.h"

using namespace std;

picture::picture(char * input)
{
	lines_ = nullptr;

	raw_input_ = input;
	raw_input_length_ = strlen(input);

	number_of_lines_ = count_lines();
	if (number_of_lines_ > PICTURE_MAX_LINES) throw ERR_PICTURE_LINES_LIMIT_EXCEEDED;
	if (number_of_lines_ == 0) throw ERR_EMPTY_PICTURE;

	max_line_length_ = max_line_length();
	if (max_line_length_ > PICTURE_MAX_LINE_LENGTH) throw ERR_PICTURE_LINE_WIDTH_LIMIT_EXCEEDED;
	try
	{
		parse_input();
	}
	catch (int e)
	{
		throw;
	}
}

int picture::count_lines() const
{
	auto count = 0;
	for (auto i = 0; i < raw_input_length_; i++)
	{
		if (raw_input_[i] == '\n') count++;
	}

	return count;
}

int picture::max_line_length() const
{
	auto count = 0;
	auto max = 0;
	for (auto i = 0; i < raw_input_length_; i++)
	{
		if (raw_input_[i] != '\n') count++;
		else
		{
			if (count > max) max = count;
			count = 0;
		}
	}

	return max;
}

void picture::parse_input()
{
	lines_ = static_cast<char**>(malloc(number_of_lines_ * sizeof(char*)));

	if (lines_ == nullptr) throw ERR_PICTURE_MEMORY_ALLOCATION_ERROR;

	const auto delim = "\n";
	char* context = nullptr;
	auto line_index = 0;
	auto token = strtok_s(raw_input_, delim, &context);

	while (token) {
		lines_[line_index] = static_cast<char*>(malloc((strlen(token) + 1) * sizeof(char)));

		if (lines_[line_index] == nullptr) throw ERR_PICTURE_MEMORY_ALLOCATION_ERROR;

		strcpy(lines_[line_index], token);
		token = strtok_s(nullptr, delim, &context);
		line_index++;
	}
}

char* picture::ret_line(const int index) const
{
	return lines_[index];
}

picture::~picture()
{
	free(raw_input_);
	for (auto i = 0; i < number_of_lines_; i++)
	{
		free(lines_[i]);
	}
	free(lines_);

#ifdef DEBUG
	cout << "[DEBUG] Deleting picture" << endl;
#endif
}

